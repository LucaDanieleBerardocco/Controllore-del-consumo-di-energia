// File .cpp realizzato da Luca Daniele Berardocco
#include "SistemaDomotico.h"
#include "DispositivoCiclico.h"
#include <sstream>
#include <iostream>
#include <cstdlib>

SistemaDomotico::SistemaDomotico(double potMax, Logger& logger) // Costruttore
    : potMax(potMax), ore(0), minuti(0), logger(logger){}

// Aggiunge un dispositivo nella "lista dei dispositivi domotici"
void SistemaDomotico::aggiungiDispositivo(const std::shared_ptr<Dispositivo>& dispositivo) 
{
    dispositivi.push_back(dispositivo);
}

// Mostra il consumo energetico di tutti i dispositivi presenti nella "lista dei dispositivi domotici"
void SistemaDomotico::mostraDispositivi() const 
{
	double consumoTotSistema = 0.0;
	double produzioneTot = 0.0;

    for (const auto& dispositivo : dispositivi) 
    {
        double consumoDispositivo = dispositivo->getConsumoTot();
        
        if(dispositivo->getConsumoTot() < 0) // Trova l'unico dispositivo che ha un consumo negativo, cioe' il fotovoltaico
        {
        	// Calcolo della produzione totale di energia da parte del fotovoltaico
			produzioneTot += -(consumoDispositivo); 
		}
        else
		{
			consumoTotSistema += consumoDispositivo; // Calcolo del consumo totale di energia
		}
	}
	std::string messaggio = "Attualmente il sistema ha prodotto " + std::to_string(produzioneTot) + " kWh e consumato " + std::to_string(consumoTotSistema) + " kWh. Nello specifico: \n";
    std::cout << "[" << getTime() << "] " << messaggio;
    logger.registraEvento(getTime(), messaggio);
	
	// Creo il ciclo per fornire in output le specifiche di tutti i dispositivi
	for (const auto& dispositivo : dispositivi) 
	{
       	double consumoDispositivo = dispositivo->getConsumoTot();
        std::string infoDispositivo;

        if (dispositivo->getNome() == "Impianto_Fotovoltaico") 
		{
        	// Output per l'Impianto Fotovoltaico (produce energia)
			infoDispositivo = "- " + dispositivo->getNome() + ", " + dispositivo->getStato() + ", ha prodotto: " +std::to_string (-consumoDispositivo) + " kWh.\n";
        } 
		else 
		{
            // Output per tutti i dispositivi che consumano energia
			infoDispositivo = "- " + dispositivo->getNome() + ", " + dispositivo->getStato() + ", ha consumato: " + std::to_string(consumoDispositivo) + " kWh.\n";
        }
    std::cout << infoDispositivo;
    logger.registraEvento(getTime(), infoDispositivo);
    }
    return;
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------

// Mostra il consumo di un determinato dispositivo dalle 00:00 fino al momento in cui viene eseguito questo comando
void SistemaDomotico::mostraDispositivo(const std::string& nomeDispositivo) const 
{
    for (const auto& dispositivo : dispositivi) 
    {
        if (dispositivo->getInfo().find(nomeDispositivo) != std::string::npos) // Controlla che il nome del dispositivo sia tra quelli validi
        {
			double consumo = dispositivo->getConsumoTot();
            std::string messaggio = "Il dispositivo '" + nomeDispositivo + "' ha attualmente consumato " + std::to_string(consumo) + " kWh [" + dispositivo->getStato() + "].";
            logger.registraEvento(getTime(), messaggio);
            return;
        }
    }
    std::string errore = "[ERRORE] Dispositivo '" + nomeDispositivo + "' non trovato.\n";
	logger.registraEvento(getTime(), errore);
	std::cout << "\n";
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------

void SistemaDomotico::Dispositivo_on(const std::string& nomeDispositivo) // Accende un determinato dispositivo 
{
    for (auto& dispositivo : dispositivi) 
    {
        if (dispositivo->getInfo().find(nomeDispositivo) != std::string::npos) 
        {
            // Controlla se il dispositivo e' ciclico
            auto dispositivoCiclico = dynamic_cast<DispositivoCiclico*>(dispositivo.get());
            if (dispositivoCiclico) 
            {
                dispositivoCiclico->avviaCiclo(); // Avvia il ciclo per i dispositivi ciclici
            } 
            else 
            {           	
					dispositivo->accendi(); // Accensione dei dispositivi manuali
        	}
            
            dispositiviAccesi.push(dispositivo); // Aggiunge il dispositivo alla pila dei dispositivi accesi
            logger.registraEvento(getTime(), "Il dispositivo "+nomeDispositivo+ " si e' acceso.\n");
            
            
			if(dispositivo->getNome() == "Impianto_Fotovoltaico" && dispositivo->isAcceso())
			{
                logger.registraEvento(getTime(), "Potenza massima del sistema aumentata di 1.5 kWh.\n");
			}
			
            controllaPotenza(); // Verifica la potenza dopo l'accensione
            std::cout << "\n";
			return;
        }
    }
    std::string errore = "[ERRORE] Dispositivo '" + nomeDispositivo + "' non trovato.\n";
	logger.registraEvento(getTime(), errore);
	std::cout << "\n";
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------

void SistemaDomotico::Dispositivo_off(const std::string& nomeDispositivo) // Spegne un determinato dispositivo 
{
    for (auto& dispositivo : dispositivi) 
    {
        if (dispositivo->getInfo().find(nomeDispositivo) != std::string::npos) // Controlla che il nome del dispositivo sia tra quelli validi
        {
            dispositivo->spegni();
            std::string messaggio = "Il dispositivo '" + nomeDispositivo + "' si e' spento.";
            logger.registraEvento(getTime(), messaggio);
            if(dispositivo->getNome() == "Impianto_Fotovoltaico" && !(dispositivo->isAcceso()))
			{
                std::string messaggioFotovoltaico = "La potenza massima del sistema e' nuovamente 3.5 kWh.";
                std::cout << messaggioFotovoltaico << "\n";
                logger.registraEvento(getTime(), messaggioFotovoltaico);
			}
			std::cout << "\n";
			return;
        }
    }
    std::string errore = "[ERRORE] Dispositivo '" + nomeDispositivo + "' non trovato.";
    logger.registraEvento(getTime(), errore);
    std::cout << "\n";
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------

// Setta i timer per i dispositivi
void SistemaDomotico::setTimer(const std::string& nomeDispositivo, int oreAcc, int minAcc, int oreSp, int minSp) 
{
    for (auto& dispositivo : dispositivi) 
    {
        if (dispositivo->getInfo().find(nomeDispositivo) != std::string::npos) 
        {
            // Controlla se il dispositivo e' ciclico
            auto dispositivoCiclico = dynamic_cast<DispositivoCiclico*>(dispositivo.get());
            if (dispositivoCiclico) 
            {
                /*Se il dispositivo e' ciclico sara' possibile impostare solo il timer di accensione
                Se l'orario risulta sbagliato, viene segnalato l'errore*/
                if (oreAcc < ore || oreAcc == ore && minAcc < minuti || oreAcc < 0 || oreAcc > 24 || minAcc < 0 || minAcc > 59) 
				{
                    std::string errore = "[ERRORE] L'orario di accensione per il dispositivo '" + nomeDispositivo + "' non risulta valido.";
                    std::cerr << errore << "\n";
                    logger.registraEvento(getTime(), errore);
				}
                // Se viene fornito un orario di spegnimento, viene segnalato un errore
                if (oreSp >= 0 || minSp >= 0) 
				{
                    std::string errore = "[ERRORE] Non e' possibile impostare un orario di spegnimento per dispositivi ciclici.\n";
                    logger.registraEvento(getTime(), errore);
                	std::cout << "\n";
				}
                dispositivo->setTimerAccensione(oreAcc, minAcc); // Viene impostato il timer di sola accensione con l'orario fornito dall'utente
                std::string message = "Impostato un timer per il dispositivo '" + nomeDispositivo + "' alle ore: " + std::to_string(oreAcc) + ":" + (minAcc < 10 ? "0" : "") + std::to_string(minAcc) + "\n";
                logger.registraEvento(getTime(), message);
            	std::cout << "\n";
			} 
			else 
			{
                /*Se il dispositivo non e' ciclico viene impostato sia il timer di accensione che quello di spegnimento (se fornito)
                Se l'orario di accensione risulta sbagliato, viene segnalato l'errore*/
				if(oreAcc < ore || oreAcc == ore && minAcc < minuti || oreAcc < 0 || oreAcc > 24 || minAcc < 0 || minAcc > 59)
            	{
                	std::string errore = "[ERRORE] L'orario di accensione per il dispositivo '" + nomeDispositivo + "' non risulta valido.\n"; 
                    logger.registraEvento(getTime(), errore);
            		std::cout << "\n";
				}
            	else
            	{
                	dispositivo->setTimerAccensione(oreAcc, minAcc); // Viene impostata l'accensione con l'orario fornito
                	std::string message = "Impostato un timer per il dispostivo '" + nomeDispositivo + "' dalle ore: " + std::to_string(oreAcc) + ":" + (minAcc < 10 ? "0" : "") + std::to_string(minAcc);
                	if (oreSp >= 0 && minSp >= 0 && oreSp > oreAcc)
                	{
                    	dispositivo->setTimerSpegnimento(oreSp, minSp); // Viene impostato lo spegnimento con l'orario fornito
                    	std::string message2 = " alle ore: " + std::to_string(oreSp) + ":" + (minSp < 10 ? "0" : "") + std::to_string(minSp) + "\n";
                        logger.registraEvento2(getTime(), message, message2);
                	}
                    else
                    {
                        logger.registraEvento(getTime(), message);
                    }
            	}
            	std::cout << "\n";
            }
            return;
        }
    }
    std::string message = "[ERRORE] Dispositivo '" + nomeDispositivo + "' non trovato.\n";
    logger.registraEvento(getTime(), message);
    std::cout << "\n";
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------

// Funzione per aggiungere un evento (accensione/spegnimento dei dispositivi)
void SistemaDomotico::aggiungiEvento(const std::string& nomeDispositivo, const std::string& azione) 
{
    eventi.push_back({getTime(), nomeDispositivo, azione});
}

// Funzione per stampare gli eventi
void SistemaDomotico::stampaEventi()  
{
    for (const auto& evento : eventi) 
    {
        std::string messaggio = "[" + evento.orario + "] Il dispositivo '" + evento.nomeDispositivo + "' si e' " + evento.azione + ".\n";
	    logger.mostraMessaggio(messaggio);  
	}
}

// Funzione per pulire gli eventi precedentemente stampati
void SistemaDomotico::clearEventi() 
{
    eventi.clear();
}
    
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------

// Verifica accensione e spegnimento dei dispositivi con un timer impostato
void SistemaDomotico::verificaTimer() 
{
    for (auto& dispositivo : dispositivi) 
    {
        // Controlla se il dispositivo e' ciclico
        auto dispositivoCiclico = dynamic_cast<DispositivoCiclico*>(dispositivo.get());
        if (dispositivoCiclico) 
        {
            dispositivoCiclico->aggiornaTempo(1);
			if (dispositivoCiclico->verificaAccensione(ore, minuti)) 
			{
                aggiungiEvento(dispositivo->getNome(), "acceso");
            }       
			if (dispositivoCiclico->verificaSpegnimento()) 
			{
                aggiungiEvento(dispositivo->getNome(), "spento");
            }         
		} 
        else 
        {
            // Verifica i timer per i dispositivi normali
            if (dispositivo->verificaAccensione(ore, minuti)) 
			{
                aggiungiEvento(dispositivo->getNome(), "acceso");
            }
            if (dispositivo->verificaSpegnimento(ore, minuti)) 
			{
                aggiungiEvento(dispositivo->getNome(), "spento");
            }
        }
    }
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------

void SistemaDomotico::avanzamentoTempo(int minutiTrascorsi) // Sommo i minuti correnti ai minuti indicati dall'utente per l'avanzamanto 
{
    for (int i = 0; i < minutiTrascorsi; ++i) 
    {
        minuti++;
        if (minuti == 60) // Se i minuti arrivano a sessanta, faccio ripartire i minuti da 0 e vado avanti di un'ora
        {
            minuti = 0;
            ore++;
        }
        // Aggiorna il tempo acceso per ogni dispositivo
        for (auto& dispositivo : dispositivi) 
        {
            dispositivo->aggiornaTempoAcc(1);
        }
        verificaTimer();
    }
    stampaEventi();
	clearEventi(); // Cancella gli eventi gia' stampati per facilitare la lettura dell'output
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------

// Consente all'utente di specificare un momento preciso nel tempo e di farlo avanzare fino al punto indicato 
void SistemaDomotico::setTime(int nuoveOre, int nuoviMinuti) 
{
    if (nuoveOre < 0 || nuoveOre > 24 || nuoviMinuti < 0 || nuoviMinuti > 59)
    {
        std::string errore = "[ERRORE] L'orario indicato non risulta valido.\n"; 
        logger.registraEvento(getTime(), errore);
        return;
    }
    if (nuoveOre < ore || (nuoveOre == ore && nuoviMinuti <= minuti)) // Se viene specificato un momento precedente a quello corrente, viene generata un'eccezione 
    {
        std::string errore = "[ERRORE] Orario fornito non valido. Deve essere futuro rispetto all'orario corrente.\n";
        logger.registraEvento(getTime(), errore);
        return;
    }
   
    if (nuoveOre == 23 && nuoviMinuti == 59) // Il programma termina alla fine della giornata
    {
		mostraDispositivi();
        std::string messaggio = "La giornata si e' conclusa. Sistema chiuso.\n";
        logger.registraEvento(getTime(), messaggio);
        exit(0); // Serve per chiudere automaticamente il programma al termine della giornata
    }
    
    int tempoTrascorso = (nuoveOre * 60 + nuoviMinuti) - (ore * 60 + minuti);
    avanzamentoTempo(tempoTrascorso);
    ore = nuoveOre;
    minuti = nuoviMinuti;
    
    std::string messaggio ="L'orario attuale e' " + getTime() + ".\n";
    logger.registraEvento(getTime(), messaggio);
    std::cout << "\n";
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------

void SistemaDomotico::resetTime() // Resetta ore e minuti e riporta tutti i dispositivi alle condizioni iniziali
{
    ore = 0;
    minuti = 0;

    for (auto& dispositivo : dispositivi) 
    {
        dispositivo->spegni();
        auto dispositivoCiclico = dynamic_cast<DispositivoCiclico*>(dispositivo.get()); 
        if (dispositivoCiclico) // Controlla se il dispositivo e' ciclico
        {
            dispositivoCiclico->resetCiclo(); // Ripristina la durata rimanente del ciclo
        }
    }
    std::string messaggio = "L'orario e' stato resettato. Tutti i dispositivi sono stati spenti. Timer esistenti sono mantenuti.\n";
    logger.registraEvento(getTime(), messaggio);
	std::cout << "\n";
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------

void SistemaDomotico::resetTimers() // Resetta i timer di tutti i dispositivi lasciandoli pero' al loro stato attuale (accesi o spenti)
{
    for (auto& dispositivo : dispositivi) 
    {
        dispositivo->rimuoviTimer();
    }
    std::string messaggio = "Tutti i timer sono stati rimossi.\n";
    logger.registraEvento(getTime(), messaggio);
	std::cout << "\n";
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------

void SistemaDomotico::resetTimerDispositivo(const std::string& nomeDispositivo) // Resetta il timer di un solo dispositivo specificato dall'utente
{
    for (auto& dispositivo : dispositivi) 
    {
        if (dispositivo->getInfo().find(nomeDispositivo) != std::string::npos) 
        {
            dispositivo->rimuoviTimer();
            std::string messaggio = "Il timer del dipositivo "+nomeDispositivo+" e' stato rimosso.\n";
            logger.registraEvento(getTime(), messaggio);
            return;
        }
    }
    std::string errore = "[ERRORE] Dispositivo '" + nomeDispositivo + "' non trovato.\n";
    logger.registraEvento(getTime(), errore);
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------

void SistemaDomotico::resetAll() // L'orario viene impostato a 00:00, tutti i timer vengono rimossi e tutti i dispositivi vengono spenti
{
    ore = 0;
    minuti = 0;
    
    for (auto& dispositivo : dispositivi) 
    {
        dispositivo->spegni();
        auto dispositivoCiclico = dynamic_cast<DispositivoCiclico*>(dispositivo.get()); 
        if (dispositivoCiclico)
        {
            dispositivoCiclico->resetCiclo();
        }
        dispositivo->rimuoviTimer();
    }
    std::string message = "L'orario e' stato impostato a 00:00, tutti i timer sono stati rimossi e tutti i dispositivi sono spenti\n";
    logger.registraEvento(getTime(), message);
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------

void SistemaDomotico::controllaPotenza() // Verifica che la somma delle potenze dei dispositivi accesi non superi il limite energetico
{
    double consumoTotale = 0.0;
    double produzioneTotale = 0.0;
    
	// Verifica se il fotovoltaico e' acceso e aggiunge 1.5 kWh alla potenza massima
    for (const auto& dispositivo : dispositivi) 
    {
        if (dispositivo->getNome() == "Impianto fotovoltaico" && dispositivo->isAcceso()) 
        {
			produzioneTotale -= dispositivo->getConsumo(); // La produzione di energia aumenta di 1.5 kWh
			break;
        }
    }
    // Somma il consumo degli altri dispositivi
	for (const auto& dispositivo : dispositivi) 
    {
        if (dispositivo->isAcceso()) // Se il dispositivo e' acceso, il suo consumo viene sommato al consumo totale
		{
			consumoTotale += dispositivo->getConsumo();	
		}	
    }
    potMax += produzioneTotale;
    
    if (consumoTotale > potMax) // Controlla se il consumo totale supera la potenza massima del sistema
    {
        std::string messaggio = "Superato il limite di potenza. Avvio spegnimento...";
        std::cout << messaggio << "\n";
        logger.registraEvento(getTime(), messaggio);
        
		// Spegne i dispositivi in ordine inverso rispetto all'accensione
        while (!dispositiviAccesi.empty() && consumoTotale > potMax) 
        {
            auto dispositivo = dispositiviAccesi.top(); // Prende il dispositivo in cima alla pila
            dispositiviAccesi.pop(); // Rimuove il dispositivo dalla pila
            
			// Evita di spegnere il frigorifero
            if (dispositivo->getNome() == "Frigorifero") 
            {
                continue; // Salta il frigorifero
            }
			
			if (dispositivo->isAcceso()) 
            {
                consumoTotale -= dispositivo->getConsumo(); // Toglie dal consumo totale il consumo dei dispositivi che vengono spenti 
                dispositivo->spegni();
                std::string messaggioSpegnimento = "Il dispositivo '" + dispositivo->getNome() + "' e' stato spento per ridurre il consumo.";
                logger.registraEvento(getTime(), messaggioSpegnimento);
            }
        }
    }
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------

void SistemaDomotico::eseguiComando(const std::string& comando) // Gestione dei comandi forniti in input
{
    std::istringstream iss(comando);
    std::string comandoPrincipale, nomeDispositivo, parametro;
    int ore, minuti, oreStop = -1, minutiStop = -1;
    
    char separatore;

    iss >> comandoPrincipale;

    if (comandoPrincipale == "set") // Caso in cui il comando dato dall'utente sia "set"
    {
        iss >> nomeDispositivo;

        if (nomeDispositivo == "time") // Caso in cui il comando dato dall'utente sia "set time": permette all'utente di specificare un momento preciso nel tempo e avanzare fino a quel punto  
        {
            // Gestione del comando "set time {ore}:{minuti}"
            std::string orario;
            if (iss >> orario) 
            {
                std::istringstream timeStream(orario);
                timeStream >> ore >> separatore >> minuti;
                setTime(ore, minuti);
            } 
            else 
            {
                std::string errore = "[ERRORE] Formato orario non valido.\n";
                logger.registraEvento(getTime(), errore);
            }
        } 
        else 
        {
            // Gestione dei dispositivi
            iss >> parametro;

            if (parametro == "on") // Caso in cui il comando dato dall'utente sia "set <dispositivo> on": accende un dispositivo
            {
                Dispositivo_on(nomeDispositivo);
            } 
            else if (parametro == "off") // Caso in cui il comando dato dall'utente sia "set <dispositivo> off": spegne un dispositivo
            {
                Dispositivo_off(nomeDispositivo);
            }  
            else if (std::isdigit(parametro[0])) // Controlla che il primo carattere dopo il dispositivo sia una cifra numerica (timer del dispositivo)
            { // Timer
                std::istringstream timeStream(parametro); // std::istringstream timeStream(parametro) mi permette di estrarre separatamente ore e minuti dalla stringa
                timeStream >> ore >> separatore >> minuti; // Dopo aver separato l'orario dalla stringa lo formatto con "ore" ":" come separatore e "minuti"

                if (iss >> oreStop >> separatore >> minutiStop) 
                {
                    if(oreStop < ore || oreStop == ore && minutiStop < minuti) // Controllo che l'orario di spegnimento del timer non sia antecedente all'orario di accensione
            		{
                        std::string errore = "[ERRORE] L'orario di spegnimento non puo' precedere l'orario di accensione.\n";
                        logger.registraEvento(getTime(), errore);
					}
					else if(oreStop < 0 || minutiStop < 0)
                    {
                        std::string errore = "[ERRORE] Tempo di spegnimento del timer errato.\n";
                        logger.registraEvento(getTime(), errore);
                    }
                    else
                    {
                        setTimer(nomeDispositivo, ore, minuti, oreStop, minutiStop);
                    }
                } 
                else 
                {
                    setTimer(nomeDispositivo, ore, minuti);
                }
            } 
            else 
            {
                std::string errore = "[ERRORE] Comando 'set' non valido.\n";
                logger.registraEvento(getTime(), errore);
            }
        }
    } 
    /*Caso in cui il comando dato dall'utente sia "show": mostra il consumo energetico totale di ogni dispositivo 
	e il consumo totale dell'intero sistema*/
	else if (comandoPrincipale == "show") 
    {
        if (iss >> nomeDispositivo) // Caso in cui venga chiesto di applicare show ad un determinato dispositivo
        {
            mostraDispositivo(nomeDispositivo);
        } 
        else 
        {
            mostraDispositivi(); // show viene applicato a tutti i dispositivi
        }
    } 
    /*Caso in cui il comando dato dall'utente sia "reset": resetta o il tempo, 
    o i timer di tutti i dipositivi, o riporta il sistema alle condizioni iniziali*/
    else if (comandoPrincipale == "reset") 
    {
        std::string tipoReset;
        iss >> tipoReset;

        if (tipoReset == "time") 
        {
            resetTime();
        } 
        else if (tipoReset == "timers") 
        {
            resetTimers();
        } 
        else if (tipoReset == "all") 
        {
            resetAll();
        } 
        else 
        {
            std::string errore = "[ERRORE] Comando 'reset' non riconosciuto.\n";
            logger.registraEvento(getTime(), errore);
        }
    }
    else if (comandoPrincipale == "rm") // Caso in cui il comando dell'utente sia "rm": toglie il timer a un determinato dispositivo
    {
        if(iss >> nomeDispositivo)
        {
            resetTimerDispositivo(nomeDispositivo);
        }
        else
        {
            std::string errore = "[ERRORE] Comando 'rm' non riconosciuto.\n";
            logger.registraEvento(getTime(), errore);
        }
    } 
    else // Caso in cui il comando dato dall'utente non esista
    {
        std::string errore = "[ERRORE] Comando " + comando + " non riconosciuto.\n";
        logger.registraEvento(getTime(), errore);
    }
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------

std::string SistemaDomotico::getTime() const // Restituisce il tempo corrente
{
    return (ore < 10 ? "0" : "") + std::to_string(ore) + ":" + (minuti < 10 ? "0" : "") + std::to_string(minuti);
}