// File .cpp realizzato da Marco 
#include <iostream>
#include "Logger.h"
#include <string>
#include <stdexcept>

Logger::Logger(const std::string& nomeFile) { // implementazione del costruttore
    
    /*Apre il file in modalita' scrittura (std::ios::out) o aggiunge nuovi messaggi in coda al file (std::ios::app)
    '.c_str()' converte un oggetto std::string in un const char* cosi' da rendenderlo compatibile con il metodo open*/
	fileLog.open(nomeFile.c_str(), std::ios::out | std::ios::app);
    
	if (!fileLog) {
    	// Errore: se il file non e' stato aperto correttamente viene lanciata l'eccezione e il programma viene terminato
		throw std::runtime_error ("[ERRORE] Impossibile aprire il file di log.\n");
	}
}

Logger::~Logger() { 
    if (fileLog.is_open()) {
        fileLog.close(); // il distruttore chiude il file se risulta aperto
    }
}

void Logger::mostraMessaggio(const std::string& messaggio) {
    std::string logMessaggio = messaggio; // stringa col messaggio da registrare
    
	if (fileLog.is_open()) {
        fileLog << logMessaggio << std::endl; // se il file di log e' aperto, scrive il messaggio formattato nel file
    }
    std::cout << logMessaggio << std::endl;
}

// implementazione del metodo registraEvento
void Logger::registraEvento(const std::string& orario, const std::string& messaggio) {
    std::string logMessaggio = "[" + orario + "] " + messaggio; // stringa col messaggio da registrare
    
	if (fileLog.is_open()) {
        fileLog << logMessaggio << std::endl; // se il file di log e' aperto, scrive il messaggio formattato nel file
    }
    std::cout << logMessaggio << std::endl;
}

// implementazione del metodo registraEvento2
void Logger::registraEvento2(const std::string& orario, const std::string& messaggio, const std::string& messaggio2) {
    std::string logMessaggio = "[" + orario + "] " + messaggio + messaggio2; // stringa col messaggio da registrare
    
	if (fileLog.is_open()) {
        fileLog << logMessaggio << std::endl; // se il file di log e' aperto, scrive il messaggio formattato nel file
    }
    std::cout << logMessaggio << std::endl;
}
