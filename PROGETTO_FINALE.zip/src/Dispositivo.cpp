// File .cpp realizzato da Tommaso 
#include "Dispositivo.h"
#include <stdexcept>
#include <iostream>

//Costruttore del dispositivo con nome, id, consumo e stato (spento all'inizio)
Dispositivo::Dispositivo(const std::string& nomeDispositivo, int idDispositivo, double consumoDispositivo)
{
    nome = nomeDispositivo;
    id = idDispositivo;
    consumo = consumoDispositivo;
    acceso = false;
    tempoAcceso = 0;
}

//Distruttore del dispositvo
Dispositivo::~Dispositivo() {}

//Accensione del dispositivo
void Dispositivo::accendi()
{
 	acceso = true; 
}

//Spegnimento del dispositivo
void Dispositivo::spegni() 
{ 
    acceso = false; 
}

//Ottengo il consumo del dispositivo, @return consumo se il dispositivo e' acceso, 0 altrimenti
double Dispositivo::getConsumo() const  
{
    if(acceso)
    {
        return consumo;
    }
    
    else
    {
        return 0.0;
    }
}

//Ottengo informazioni sul dispositivo, @return la stringa "info" con nome, id, consumo e stato
//Utilizzo il metodo to_string della libreria std per convertire id e consumo in stringhe, per poi usare l'operatore + di concatenazione
std::string Dispositivo::getInfo() const // Funzione ausiliaria
{
    std::string info;
    info += "Nome dispositivo: " + nome;
    info += ", ID: " + std::to_string(id); 
    info += ", Consumo: " + std::to_string(consumo) + " kW/h";
    
    std::string stato = acceso ? " acceso" : " spento";
    info += ", Stato:" + stato;
    return info;
}

//Ottendo il nome del dispositivo, @return nome
//Tramite il metodo getter sono sicuro di non violare l'incapsulamento
std::string Dispositivo::getNome() const 
{ 
	return nome; 
}

//Ottengo l'id del dispositivo, @return stato
std::string Dispositivo::getStato() const 
{ 
    std::string info;
	std::string stato = acceso ? " acceso" : " spento";
    info += "Stato:" + stato;
    return info;
}

//Informa se il dispositivo e' acceso, @return true se il dispositivo e' acceso
bool Dispositivo::isAcceso() const 
{
    return acceso;
}

// Metodo per aggiornare il tempo acceso
void Dispositivo::aggiornaTempoAcc(int minuti) 
{
    if (acceso) 
	{
        tempoAcceso += minuti;
    }
}

// Metodo per calcolare il consumo totale
double Dispositivo::getConsumoTot() const 
{
    double oreAccese = tempoAcceso / 60.0; // Converti i minuti in ore
    return oreAccese * consumo; // Moltiplica per il consumo orario
	//return (tempoAcceso / 60.0) * consumo; // Converti minuti in ore e moltiplica per il consumo
}

//Imposto il timer di accensione 
/*Controllo se l'orario risulta all'interno dell'intervallo di validita' di ore e minuti, 
in caso contrario viene segnalato l'errore*/
void Dispositivo::setTimerAccensione(int ore, int minuti) 
{
    if(ore < 0 || ore > 23 || minuti < 0 || minuti > 59)
    {
        std::cerr << "[ERRORE] Orario di accensione non valido"; //utilizzo di std::cerr per non far bloccare il programma
    }
    else
    {
        timerAccensione = {ore, minuti};
    }
}

//Imposto il timer di spegnimento 
/*Controllo se l'orario risulta all'interno dell'intervallo di validita' di ore e minuti, 
in caso contrario viene segnalato l'errore*/
void Dispositivo::setTimerSpegnimento(int ore, int minuti) 
{
    if(ore < 0 || ore > 23 || minuti < 0 || minuti > 59)
    {
        std::cerr << "[ERRORE] Orario di spegnimento non valido"; //utilizzo di std::cerr per non far bloccare il programma
    }
    else
    {
        timerSpegnimento = {ore, minuti};
    }
}

//Rimuove il timer 
//Impostando il valore -1 nelle ore e minuti di entrambi i timer, necessariamente debbono essere fermi
void Dispositivo::rimuoviTimer() 
{
    timerAccensione = {-1, -1};
    timerSpegnimento = {-1, -1};
}

//Verifica l'accensione del dispositivo, @return true se il dispostivo e' acceso
//Verifica la validita' di ore e minuti, in tal caso segnala l'errore
bool Dispositivo::verificaAccensione(int ore, int minuti) 
{
    if (ore < 0 || ore > 24 || minuti < 0 || minuti > 59)
    {
        std::cerr << "[ERRORE] L'orario settato non risulta valido"; //utilizzo di std::cerr per non far bloccare il programma
        return false;
    }
    else 
    {
        if (timerAccensione.first == ore && timerAccensione.second == minuti) 
        {
            accendi();
            return true;
        }
        return false;
    }
}

//Verifico lo spegnimento del dispositivo, @return true se il dispositivo e' spento 
//Verifica la validita' di ore e minuti, in tal caso segnala l'errore
bool Dispositivo::verificaSpegnimento(int ore, int minuti) 
{
     if (ore < 0 || ore > 24 || minuti < 0 || minuti > 59)
    {
        std::cerr << "[ERRORE] L'orario settato non risulta valido"; //utilizzo di std::cerr per non far bloccare il programma
        return false;
    }
    else
    {
        if (timerSpegnimento.first == ore && timerSpegnimento.second == minuti) 
        {
            spegni();
            return true;
        }
        return false;
    }
}
