// File .cpp realizzato da Marco
#include <iostream>
#include "SistemaDomotico.h"
#include "Logger.h"
#include "DispositivoCiclico.h"

int main() {
    Logger logger("log.txt");
    SistemaDomotico sistema(3.5, logger); // Potenza massima 3.5 kW 
     

    // Aggiunta di dispositivi
    /*std::make_shared e' una funzione della libreria standard che crea un oggetto dinamico e restituisce un std::shared_ptr 
	che lo gestisce. Un std::shared_ptr e' un tipo di smart pointer che permette la condivisione di proprieta' di uno stesso
	oggetto tra diverse componenti del programma. Inoltre garantisce che la memoria venga gestita correttamente senza 
	bisogno di deallocazione manuale, prevenendo il memory leak.
	I parametri passati sono il nome del dispositivo e l'ID e il consumo energetico per tutti i dispositivi; 
	la durata del ciclo per i dispositivi ciclici*/
    sistema.aggiungiDispositivo(std::make_shared<Dispositivo>("Impianto_Fotovoltaico", 1, -1.5));
    sistema.aggiungiDispositivo(std::make_shared<DispositivoCiclico>("Lavatrice", 2, 2.0, 110));
    sistema.aggiungiDispositivo(std::make_shared<DispositivoCiclico>("Lavastoviglie", 3, 1.5, 195));
    sistema.aggiungiDispositivo(std::make_shared<Dispositivo>("Pompa_di_Calore+Termostato", 4, 2.0));
    sistema.aggiungiDispositivo(std::make_shared<DispositivoCiclico>("Tapparelle_Elettriche", 5, 0.3, 1));
    sistema.aggiungiDispositivo(std::make_shared<Dispositivo>("Scaldabagno", 6, 1.0));
    sistema.aggiungiDispositivo(std::make_shared<Dispositivo>("Frigorifero", 7, 0.4));
    sistema.aggiungiDispositivo(std::make_shared<DispositivoCiclico>("Forno_a_Microonde", 8, 0.8, 2));
    sistema.aggiungiDispositivo(std::make_shared<DispositivoCiclico>("Asciugatrice", 9, 0.5, 60));
    sistema.aggiungiDispositivo(std::make_shared<DispositivoCiclico>("Televisore", 10, 0.2, 60));

    // Ciclo principale per i comandi
    std::string comando;
    std::cout << "\nBenvenuto nel Sistema Domotico: i comandi disponibili sono:\n"
              << "  - set <dispositivo> on/off\n"
              << "  - set <dispositivo> <hh:mm> <hh:mm>\n" // setta il timer per i dispositivi
              << "  - rm <dispositivo>\n" // rimuove il timer di un preciso dispositivo
              << "  - show\n" // mostra i dati di tutti i dispositivi
              << "  - show <dispositivo>\n"
              << "  - set time <hh:mm>\n"
              << "  - reset time/timers/all\n"
              << "  - exit\n";
    std::cout << "-----------------------------------------------------------------------------------------\n"
			  << "I dispositivi disponibili sono:\n"
              << "  - Impianto_Fotovoltaico\n"
              << "  - Lavatrice\n"
              << "  - Lavastoviglie\n"
              << "  - Pompa_di_Calore+Termostato\n"
              << "  - Tapparelle_Elettriche\n"
              << "  - Scaldabagno\n"
              << "  - Frigorifero\n"
              << "  - Forno_a_Microonde\n"
              << "  - Asciugatrice\n"
              << "  - Televisore\n"
              << "-----------------------------------------------------------------------------------------\n";

    // Ciclo while per permettere all'utente di inserire tutti i comandi che desidera finche' non digita 'exit'
    while (true) 
    {
        std::cout << "Inserisci un comando: ";
        std::getline(std::cin, comando);

        if (comando == "exit") 
        {
            logger.registraEvento(sistema.getTime(), "Chiusura del sistema.");
            std::cout << "\n";
            break; // digitando 'exit' si esce dal ciclo: il programma termina
        }
        logger.registraEvento(sistema.getTime(), "Eseguito comando: " + comando); // il comando eseguito viene registrato nel file di log
        sistema.eseguiComando(comando);
        sistema.controllaPotenza(); // verifica che il consumo energetico non superi il limite massimo
    }
    return 0;
}
