// File .cpp realizzato da Tommaso
#include "DispositivoCiclico.h"
#include <stdexcept>
#include <iostream>

//Costruttore del dispositivo ciclico, inizialmente spento
DispositivoCiclico::DispositivoCiclico(const std::string& nomeDispositivoCiclico, int idDispositivoCiclico, double consumoDispositivoCiclico, int durataDispositivoCiclico)
    : Dispositivo(nomeDispositivoCiclico, idDispositivoCiclico, consumoDispositivoCiclico), durata(durataDispositivoCiclico), tempoRimanente(0) {}

//Avvio del ciclo ed accensione del dispositivo
//Inizialmente il tempo rimanente sara' uguale alla durata intera del ciclo
void DispositivoCiclico::avviaCiclo() 
{
    accendi();
    tempoRimanente = durata;
}

//Aggiorna il tempo rimanente alla fine del ciclo
//Sottrae al tempo rimanente i minuti passati come parametro se entrambi positivi, altrimenti spegne il dispositivo
void DispositivoCiclico::aggiornaTempo(int minuti) 
{
    if (acceso && tempoRimanente > 0) 
    {
        tempoRimanente -= minuti;
    }
    else
    {
        spegni();
        tempoRimanente = 0;
    }
}

/*Verifica l'accensione del dispositivo ciclico, @return true se il dispositivo e' acceso
Controlla ore e minuti nei parametri e se il dispostivo e' spento, in caso contrario accende il dispostivo ed avvia il ciclo
Controllo ulteriore sull'intervallo di validita' delle ore e minuti e segnalazione dell'errore*/
bool DispositivoCiclico::verificaAccensione(int ore, int minuti) 
{
    if(ore < 0 || ore > 24 || minuti < 0 || minuti > 59)
    {
        std::cerr << "L'orario settato non risulta valido"; //utilizzo di std::cerr per non far bloccare il programma
        return false;
    }
    else
    {
        if (timerAccensione.first == ore && timerAccensione.second == minuti && !acceso) 
        {
            avviaCiclo(); 
            return true;
        }
        return false;
    }
}

/*Verifica che il ciclo sia terminato e quindi che sia avvenuto lo spegnimento del dispositivo, 
@return true se il dispositivo e' spento*/
bool DispositivoCiclico::verificaSpegnimento() 
{
    if (acceso && tempoRimanente <= 0) 
    {
        spegni();
        tempoRimanente = 0;
        return true;
    }
    return false;
}

//Ripristina la durata rimanente al valore iniziale e spegne il dispositivo
void DispositivoCiclico::resetCiclo() 
{
    tempoRimanente = durata; 
    spegni();              
}

/*Ottengo le informazioni sul dispositivo, @return la stringa data dalla funzione getInfo() della classe madre con 
nome, id, consumo e stato ed inoltre la durata rimanente del ciclo. 
Tramite to_string della classe std converto in stringa il tempo rimanente per concatenarlo alla stringa di return*/
std::string DispositivoCiclico::getInfo() const 
{
    return Dispositivo::getInfo() + " con ciclo di durata rimanente: " + std::to_string(tempoRimanente) + " minuti";
}
