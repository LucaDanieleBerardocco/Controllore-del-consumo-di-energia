// File .h realizzato da Tommaso
#ifndef DISPOSITIVO_H
#define DISPOSITIVO_H

#include <string>

//Un dispositivo e' necessariamente individuato dal suo nome, id e consumo
class Dispositivo {
protected:
    std::string nome;
    int id;
    double consumo; // consumo in kW/h
    std::string stato; // acceso/spento
	bool acceso;
    int tempoAcceso; // tempo totale in cui il dispositivo e' stato acceso
    
    //Utilizzando pair della classe std otteniamo la corrispondenza tra ore e minuti, nel formato hh:mm, funzionale per i timer
    //L'utente non deve avere accesso ai timer, pertanto sono dichiarati private
    std::pair<int, int> timerAccensione; 
    std::pair<int, int> timerSpegnimento; 

public:
    //Costruttore del dispositivo con il suo nome, l'id, il consumo
    Dispositivo(const std::string& nomeDispositivo, int idDispositivo, double consumoDispositivo); 
    //Distruttore del dispositivo
    virtual ~Dispositivo(); 
    //Accensione del dispositivo
    virtual void accendi(); 
    //Spegnimento del dispositivo
    virtual void spegni(); 
    //Consumo del dispositivo
    virtual double getConsumo() const; 
    //Informazioni sul dispostivo
    virtual std::string getInfo() const; 
    //Nome del dispositivo
	virtual std::string getNome() const;
    //Id del dispositivo
    virtual std::string getStato() const; 
    //Controllo di accensione
    bool isAcceso() const; 
    //Aggiorna il tempo acceso
    void aggiornaTempoAcc(int minuti);
    //Calcola il consumo totale
    virtual double getConsumoTot() const;

   //Funzioni per il timer
    //Imposta il timer di accensione
    void setTimerAccensione(int oreAccensione, int minutiAccensione); 
    //Imposta il timer di spegnimento 
    void setTimerSpegnimento(int oreSpegnimento, int minutiSpegnimento); 
    //Rimuove il timer
    void rimuoviTimer(); 
    //Verifica l'accensione del timer
    virtual bool verificaAccensione(int ore, int minuti); 
    //Verifica lo spegnimento del timer
    virtual bool verificaSpegnimento(int ore, int minuti); 
};

#endif 
