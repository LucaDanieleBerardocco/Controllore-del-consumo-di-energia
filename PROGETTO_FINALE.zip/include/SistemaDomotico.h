// File .h realizzato da Luca Daniele Berardocco
#ifndef SISTEMA_DOMOTICO_H
#define SISTEMA_DOMOTICO_H

#include <iostream>
#include <vector>
#include <memory>
#include <string>
#include <utility>
#include <stack>
#include "Logger.h"
#include "Dispositivo.h"

class SistemaDomotico 
{
    private:
        std::vector<std::shared_ptr<Dispositivo>> dispositivi; //Lista dei dispositivi
        double potMax; //Potenza Massima
        int ore;    // Ora corrente nel sistema
        int minuti; // Minuti correnti nel sistema
        // Pila per i dispositivi accesi, serve nel controlloPotenza() per spegnere i dispositivi in ordine inverso a quello di accensione
		std::stack<std::shared_ptr<Dispositivo>> dispositiviAccesi;
		/*std::shared_ptr e' un tipo di smart pointer che permette la condivisione di proprieta' di uno stesso
		oggetto tra diverse componenti del programma. Inoltre garantisce che la memoria venga gestita correttamente senza 
		bisogno di deallocazione manuale, prevenendo il memory leak.*/ 
        
        // Struttura per memorizzare gli eventi da stampare in output
    	struct Evento 
        {
        	std::string orario;
        	std::string nomeDispositivo;
        	std::string azione; // "acceso" o "spento"
    	};

    	std::vector<Evento> eventi; // Lista degli eventi
        Logger& logger; //Riferimento al Logger

    public:
        SistemaDomotico(double potMax, Logger& logger); // Costruttore

    // Gestione dispositivi
    void aggiungiDispositivo(const std::shared_ptr<Dispositivo>& dispositivo);
    void mostraDispositivi() const; 
    void mostraDispositivo(const std::string& nomeDispositivo) const; 
    void Dispositivo_on(const std::string& nomeDispositivo);
    void Dispositivo_off(const std::string& nomeDispositivo);

    // Gestione timer
    void setTimer(const std::string& nomeDispositivo, int oreAcc, int minAcc, int oreSp = -1, int minSp = -1);
    void aggiungiEvento(const std::string& nomeDispositivo, const std::string& azione);
    void stampaEventi();
	void clearEventi();
	void verificaTimer();
    void avanzamentoTempo(int minutiTrascorsi);
    void setTime(int nuoveOre, int nuoviMinuti);
    
    // Reset e gestione consumi
    void resetTime();
    void resetTimers();
    void resetTimerDispositivo(const std::string& nomeDispositivo); 
    void resetAll();
    void controllaPotenza();

    // Gestione comandi
    void eseguiComando(const std::string& comando);

    // Utility
    std::string getTime() const;
};

#endif //SISTEMA_DOMOTICO_H
