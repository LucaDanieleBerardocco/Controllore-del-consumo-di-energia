// File .h realizzato da Tommaso
#ifndef DISPOSITIVO_CICLICO_H
#define DISPOSITIVO_CICLICO_H

#include "Dispositivo.h"

//Estensione della classe "Dispositivo" sono i dispositivi con ciclo prefissato, i cui elementi portanti sono: la durata del ciclo stesso ed il tempo rimanente prima dello spegnimento
class DispositivoCiclico : public Dispositivo { 
private:
    int durata;
    int tempoRimanente;

public:
    //Costruttore di un dispositivo ciclico, pressoche' analogo a quello della classe madre
    DispositivoCiclico(const std::string& nomeDispositivoCiclico, int idDispositivoCiclico, double consumoDispositivoCiclico, int durataDispositivoCiclico);
    //Avvia il ciclo del dispositivo
    void avviaCiclo();
    //Aggiorna il tempo rimanente del ciclo
    void aggiornaTempo(int minuti);
    //Riavvia il ciclo
    void resetCiclo();

    //Sovrascrittura di getInfo rispetto alla classe madre, con l'informazione sulla durata rimanente del ciclo
    std::string getInfo() const override; 
    //Sovrascrittura di verificaAccensione della classe madre
    bool verificaAccensione(int ore, int minuti) override;
    //Metodo per verificare la fine del ciclo e lo spegnimento del dispositivo
	bool verificaSpegnimento();
};

#endif // DISPOSITIVO_CICLICO_H

