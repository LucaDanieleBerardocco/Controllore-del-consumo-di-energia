// File .h realizzato da Marco
#ifndef LOGGER_H
#define LOGGER_H

#include <fstream> // libreria necessaria per lavorare con i file
#include <string>

class Logger {
private:
    std::ofstream fileLog; // oggetto per scrivere i messaggi di log su file
    std::string nomeFile;
    
public:
    Logger(const std::string& nomeFile); // dichiarazione del costruttore della classe
    ~Logger(); // dichiarazione del distruttore, chiude il file quando l'oggetto Logger viene distrutto

    // Funzione per stampare un messaggio (funzione ausiliaria per stampaEventi())
    void mostraMessaggio(const std::string& messaggio);
    
    // Funzioni per registrare un evento, i paramentri sono l'orario e il messaggio da registrare
	void registraEvento(const std::string& orario, const std::string& messaggio);
    void registraEvento2(const std::string& orario, const std::string& messaggio, const std::string& messaggio2);
};

#endif // LOGGER_H
